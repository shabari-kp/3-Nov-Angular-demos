import { Component } from '@angular/core';

@Component({
  selector: 'app-for-loop-example',
  templateUrl: './for-loop-example.component.html',
  styleUrls: ['./for-loop-example.component.css']
})
export class ForLoopExampleComponent {
  people: any[] = [
    {
      "name": "Tobia"
    },
    {
      "name": "Alex"
    },
    {
      "name": "Brad Green"
    },
    {
      "name": "Juri"
    },
    {
      "name": "Samson"
    }
  ];
}
