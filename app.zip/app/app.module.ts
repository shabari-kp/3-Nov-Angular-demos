import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ForLoopExampleComponent } from './for-loop-example/for-loop-example.component';
import { IfElseExampleComponent } from './if-else-example/if-else-example.component';
import { SwtichExampleComponent } from './swtich-example/swtich-example.component';
import { ReservedWordsDemoComponent } from './reserved-words-demo/reserved-words-demo.component';
import { AttributeDirectiveDemosComponent } from './attribute-directive-demos/attribute-directive-demos.component';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,
    ForLoopExampleComponent,
    IfElseExampleComponent,
    SwtichExampleComponent,
    ReservedWordsDemoComponent,
    AttributeDirectiveDemosComponent
  ],
  imports: [
    BrowserModule,
    CommonModule      ,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
}),

export class AppModule { }
