import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservedWordsDemoComponent } from './reserved-words-demo.component';

describe('ReservedWordsDemoComponent', () => {
  let component: ReservedWordsDemoComponent;
  let fixture: ComponentFixture<ReservedWordsDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReservedWordsDemoComponent]
    });
    fixture = TestBed.createComponent(ReservedWordsDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
