import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwtichExampleComponent } from './swtich-example.component';

describe('SwtichExampleComponent', () => {
  let component: SwtichExampleComponent;
  let fixture: ComponentFixture<SwtichExampleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SwtichExampleComponent]
    });
    fixture = TestBed.createComponent(SwtichExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
