import { Component } from '@angular/core';

@Component({
  selector: 'app-swtich-example',
  templateUrl: './swtich-example.component.html',
  styleUrls: ['./swtich-example.component.css']
})
export class SwtichExampleComponent {

  people: any[] = [
    {
      "name": "Goomes",
      "age": 35,
      "country": 'IND'
    },
    {
      "name": "David",
      "age": 32,
      "country": 'US'
    },
    {
      "name": "Misko",
      "age": 21,
      "country": 'JPN'
    },
    {
      "name": "Hevery",
      "age": 34,
      "country": 'UK'
    },
    {
      "name": "Don",
      "age": 32,
      "country": 'JPN'
    }
  ];
}
